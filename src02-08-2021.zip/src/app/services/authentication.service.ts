import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Platform, AlertController } from '@ionic/angular';
import { map, tap, switchMap, catchError } from 'rxjs/operators';
import { BehaviorSubject, from, Observable, Subject } from 'rxjs';
import { Storage } from '@capacitor/storage';
import { State } from '../pages/profile-form/state.model';


const TOKEN_KEY = 'my-token';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  // Init with null to filter out the first value in a guard!
  isAuthenticated: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  token = '';

  constructor(
    private http: HttpClient,
    private alertController: AlertController
  ) {
    this.loadToken();
  }

  async loadToken() {
    const token = await Storage.get({ key: TOKEN_KEY });
    if (token && token.value) {
      console.log('set token: ', token.value);
      this.token = token.value;
      this.isAuthenticated.next(true);
    } else {
      this.isAuthenticated.next(false);
    }
  }

  login(credentials): Observable<any> {
    // return this.http.post(`https://reqres.in/api/login`, credentials).pipe(
    return this.http.post(`http://localhost:3000/api/sdetails/login`, credentials).pipe(
      map((data: any) => data.token),
      switchMap(token => {
        return from(Storage.set({ key: TOKEN_KEY, value: token }));
      }),
      tap(_ => {
        this.isAuthenticated.next(true);
      })
    )
  }


  register(credentials) {
    return this.http.post(`http://localhost:3000/api/sdetails`, credentials).pipe(
      catchError(e => {
        this.showAlert(e.error.msg);
        throw new Error(e);
      })
    );
  }

  setProfileSecond(myformSecond) {
    return this.http.post(`http://localhost:3000/api/saddress/`, myformSecond).pipe(
      catchError(e => {
        this.showAlert(e.error.msg);
        throw new Error(e);
      })
    );
  }

  getuser(idstudent_details: string) {
    return this.http.get<{ message: string, cdata: any }>(`http://localhost:3000/api/sdetails/` + idstudent_details);

  }

  getStudentList() {
    return this.http.get<{ message: string, cdata: any }>(`http://localhost:3000/api/sdetails/`);
  }

  getStateList() {
    return this.http.get<{ message: string, slist: State[] }>(`http://localhost:3000/api/state/`);
  }

  getCityList() {
    return this.http.get<{ message: string, slist: State[] }>(`http://localhost:3000/api/city/`);
  }

  getLanguageList() {
    return this.http.get<{ message: string, slist: State[] }>(`http://localhost:3000/api/lang/`);
  }


  setPassword(idstudent_details: string, myform) {
    return this.http.put<{ message: string, cdata: any }>(`http://localhost:3000/api/sdetails/` + idstudent_details, myform);

  }

  setProfileFirst(idstudent_details: string, myformThird) {
    return this.http.put<{ message: string, cdata: any }>(`http://localhost:3000/api/sdetails/profile/` + idstudent_details, myformThird);

  }

  setProfileThird(idstudent_details: string, myform) {
    return this.http.put<{ message: string, cdata: any }>(`http://localhost:3000/api/sdetails/pthird/` + idstudent_details, myform);

  }

  showAlert(msg) {
    let alert = this.alertController.create({
      message: msg,
      header: 'registration failed',
      buttons: ['OK']
    });
    alert.then(alert => alert.present());
  }

  logout(): Promise<void> {
    this.isAuthenticated.next(false);
    return Storage.remove({ key: TOKEN_KEY });
  }

}