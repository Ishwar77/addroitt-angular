import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StudentDetailsPage } from './student-details.page';

const routes: Routes = [
  {
    path: '',
    component: StudentDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentDetailsPageRoutingModule {}
