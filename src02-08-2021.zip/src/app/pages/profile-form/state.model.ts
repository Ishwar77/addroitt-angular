export interface State {
    'idstate': string;
    'idcountry': string,
    'state': string,
}
