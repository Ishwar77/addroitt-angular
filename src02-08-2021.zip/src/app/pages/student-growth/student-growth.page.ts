import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-growth',
  templateUrl: './student-growth.page.html',
  styleUrls: ['./student-growth.page.scss'],
})
export class StudentGrowthPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
