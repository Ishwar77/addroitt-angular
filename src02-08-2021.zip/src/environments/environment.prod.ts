export const environment = {
  production: true,
  apiUrl : 'https://newsapi.org/v2/',
  apiKey : 'ca2e4d47161f4fbeaf137e4041957b65',
};
